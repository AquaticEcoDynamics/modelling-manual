#!/bin/sh

../macGLM/glm.app/Contents/MacOS/glm --xdisp $*
