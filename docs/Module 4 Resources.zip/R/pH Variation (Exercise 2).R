# Fixed values
CO2<- 3.5E-4
Ca2<-5E-4
pH<-c(4,5,6,7,8,9,10,11,12)

# Declare NULL for things in the for loop
# You need to declare all the looped variables as NULL
H<-NULL
OH<-NULL
pOH<-NULL  
  
# The for loop
for(i in 1:length(pH)){
  H[i]<-10^(-1*pH[i])
  OH[i]<-Kw/H[i]
#   H2CO3[i]<-
#   HCO3[i]<-
#   CO3[i]<-
   
  
  pOH[i]<- -log10(OH[i])
#   pH2CO3[i]<- -log10(H2CO3[i])
#   pHCO3[i]<- -log10(HCO3[i])  
#   pCO3[i]<- -log10(CO32[i])
}# End for i loop

#png(file="loglog.png")
plot(pH,pH
     ,col="white"
     ,ylab = "log of concentration"
     ,ylim=c(-12, 12)
     )
lines(pH,pH,col="black")
text(11.5,11,"pH",col="black")
lines(pH,pOH,col="blue")
text(4.5,10.5,"pOH",col="blue")
#dev.off()
