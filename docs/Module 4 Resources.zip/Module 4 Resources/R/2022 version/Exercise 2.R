library(tidyverse)

# Fixed values
CO2 <- 3.5E-4
Ca2 <- 5E-4
pH <- c(4,5,6,7,8,9,10,11,12)
K1 <- 1*10^(-6.3)
pK1 <- -log10(K1)
pK2 <- -log10(K2)

# Initialise an empty data frame
model <- data.frame(
  pH = pH,
  H = rep(0,length(pH)),
  OH = rep(0,length(pH)),
  pOH = rep(0,length(pH)),
  CO3 = rep(0,length(pH)),
  logH = rep(0,length(pH)),
  logOH = rep(0,length(pH))#,
  # logH2CO3 = 
  # logHCO3 = 
  # logCO3 = 
)

# The for loop
for(i in 1:length(pH)){
  model$H[i]<-10^(-1*pH[i])
  model$OH[i]<-Kw/model$H[i]
  # model$H2CO3[i]<-
  # model$HCO3[i]<-
  # model$CO3[i]<- 
  
  model$logH[i] <- log10(model$H[i])
  model$logOH[i]<- log10(model$OH[i])
  # model$logH2CO3[i]<- log10(model$H2CO3[i])
  # model$logHCO3[i] <- log10(model$HCO3[i])  
  # model$logCO3[i]  <- log10(model$CO3[i])
}

# Plot with ggplot
ggplot() +
  geom_line(data = model, mapping = aes(x = pH, y = logH), colour = "red") +
  geom_line(data = model, mapping = aes(x = pH, y = logOH), colour = "black") +
  theme_light()

# Save plot as a .png
ggsave(
  filename = "exercise2.png",
  height = 2000,
  width = 2000,
  units = 'px',
  dpi = 500,
  scale = 1.5
)


