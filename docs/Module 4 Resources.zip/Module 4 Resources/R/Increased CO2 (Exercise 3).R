
CO2new<-CO2*2 # From the previous exercises * (for example) 2
verysmallnumber<-1e-2

pH<-NULL; H<-NULL; pHDiff<-NULL

pH[1]<-8.3
H[1]<- 10^(-1*pH[1])


for(j in 2:30){
  H[j]<- H[j-1]*0.5#( H2CO3[j-1]/CT[j-1]*(H[j-1]^2+K1*H[j-1]+K1*K2) )^(1/2)
  pH[j]<- -log10(H[j])
  pHDiff<- pH[j]-pH[j-1]

  
  if(abs(pHDiff)<verysmallnumber){ # If the absolute value of the pH difference is small
    print(j)  # then print the iteration number j to the screen
    stop("All done!") # stop the calculations, and write "All done!" to the screen
  }
  
  
  
}