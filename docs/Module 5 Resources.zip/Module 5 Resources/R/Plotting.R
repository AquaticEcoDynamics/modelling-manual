#You should know now how to make a png file, and save it where you need to.
#If you do not, then have a look at Module 2 and 4, or google it.
#f you want to put more than one variable on the same axis, use the functions 'points' or 'lines'

plot(time,P)
plot(time,Stot)
plot(time,Ssat)
plot(time,Sus)
plot(time,Susprime)
plot(time,Stotprime)
plot(time,etot)
plot(time,Qtot)

