#plot(time,P)

plot(time,Stot)
plot(time,Ssat)
plot(time,Sus)
plot(time,Susprime)
plot(time,Stotprime)
plot(time,etot)
plot(time,Qtot)

