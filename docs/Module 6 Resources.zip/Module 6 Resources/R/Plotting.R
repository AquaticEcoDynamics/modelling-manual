library(tidyverse)

C %>% 
  rownames_to_column("timeStep") %>%  # Wrangle the matrix into a 'tidy' format
  pivot_longer(cols = -c(timeStep), names_to = "gridSegment") %>% 
  mutate(
    timeStep = as.numeric(timeStep), # Convert columns of character data to numeric 
    gridSegment = as.numeric(gridSegment)
  ) %>% 
  ggplot(mapping = aes(x = gridSegment, y = timeStep, fill = value)) +  # Plot with ggplot()
  geom_raster() +
  scale_fill_viridis_c() +  
  scale_x_continuous(expand=c(0,0))+
  scale_y_continuous(expand=c(0,0)) +
  labs(x = "Grid Segment", y = "Time-step", fill = "O2 (mg/L)")

# Save your plot with ggsave()
ggsave(
  filename = "O2.png",
  width = 2000,
  height = 1750,
  units = 'px'
)

