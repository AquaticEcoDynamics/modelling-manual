library(tidyverse)

# Number of iterations for the j loop
nInterations  <- 1000

# Set the constants
CO2<-3.5E-4
CO2multiplier<-c(1,1.2,1.4,1.6,1.8,2)
K1<-1*10^(-6.3)
K2<-1*10^(-10.3)
Kw<-1*10^-14
KH<- 1*10^(-1.47)
CT<-1.185955e-03

# Initialise the data frame of the final modeled H and pH values for each CO2 multiplier
finalResults  <- data.frame(
  pH = rep(0,length(CO2multiplier)),
  H = rep(0,length(CO2multiplier)),
  multiplier = rep(0,length(CO2multiplier))
)

# Initialise the data frame for the iterated H and pH values
model  <- data.frame(
  pH = rep(0,nInterations),
  H = rep(0,nInterations),
  iteration = rep(0,nInterations)
)

# Set the initial values
model$pH[1] <- 8.3
model$H[1] <- 10^(-1*model$pH[1])
model$iteration[1] <- 1

# Run the k and j loops
for(k in 1:length(CO2multiplier)){
  CO2new<-CO2*CO2multiplier[k]
  H2CO3<-KH*CO2new
  for(j in 2:nInterations){
    model$H[j] <- (H2CO3/CT*((model$H[j-1]^2)+K1*model$H[j-1]+K1*K2))^(1/2)
    model$pH[j]<- -log10(model$H[j])
    model$iteration[j]  <- j
  }
  finalResults$H[k]  <- model$H[j]
  finalResults$pH[k]  <- model$pH[j]
  finalResults$multiplier[k]  <- CO2multiplier[k]
}


# Plot the final pH values for each multiplier
ggplot(data = finalResults, mapping = aes(x = multiplier, y = pH))+
  geom_line(colour="red") +
  scale_y_continuous(limits = c(7.8, 8.4))+
  theme_classic()

# Save plot as a .png
ggsave(
  filename = "exercise3-1.png",
  height = 2000,
  width = 2000,
  units = 'px',
  dpi = 500,
  scale = 1.5
)

# Plot the modeled iterations for pH at a the 2x CO2 multiplier
ggplot(data = model, mapping = aes(x = iteration, y = pH))+
  geom_line(colour = "red")+
  scale_y_continuous(limits = c(7.8, 8.4))+
  scale_x_continuous(limits = c(0, 10))+
  theme_classic()

# Save plot as a .png
ggsave(
  filename = "exercise3-2.png",
  height = 2000,
  width = 2000,
  units = 'px',
  dpi = 500,
  scale = 1.5
)


