library(tidyverse)

# Define the plot's colour palette
colourPalette <- c(
  "red","orangered","gold","lightgoldenrod3","gray80","paleturquoise","turquoise1","turquoise2","deepskyblue", "mediumaquamarine", 
  "palegreen1", "chartreuse", "chartreuse1","chartreuse2", "chartreuse3", "chartreuse4", "darkgreen")

C %>% 
  rownames_to_column("timeStep") %>%  # Wrangle the matrix into a 'tidy' format
  pivot_longer(cols = -c(timeStep), names_to = "gridSegment") %>% 
  mutate(
    timeStep = as.numeric(timeStep), # Convert columns of character data to numeric 
    gridSegment = as.numeric(gridSegment)
  ) %>% 
  ggplot(mapping = aes(x = gridSegment, y = timeStep, fill = value)) +  # Plot with ggplot()
  geom_raster() +
  scale_fill_gradientn( # Apply the colour palette
    colours= colourPalette, 
    limits = c(1,17),
  ) +  
  scale_x_continuous(expand=c(0,0), position = "top")+
  scale_y_reverse(expand=c(0,0)) +
  labs(x = "Grid Segment", y = "Time-step", fill = "O2 (mg/L)")

# Save your plot with ggsave()
ggsave(
  filename = "O2.png",
  width = 2000,
  height = 1750,
  units = 'px'
)

